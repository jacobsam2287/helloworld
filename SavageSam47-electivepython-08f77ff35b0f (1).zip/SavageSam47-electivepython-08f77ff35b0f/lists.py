l=[]
a = int(input("How many items would you like to add?"))
#SAYS HOW MANY IS ADDED
for c in range(a):
    b = input("What would you like to add")
    #ADDS B A AMOUT OF TIMES
    l.append(b)
    #ADDS TO LIST
print("Ok i will remember this")
for z in range(0,a):
    print(l[z])
#PRINTS LIST