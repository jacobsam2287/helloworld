for a in range(100):
    print("")
    for c in range(a):
        print("*", end="")