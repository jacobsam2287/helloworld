from random import randint
b=randint(1,100)
for a in range(1,100):
    print(a)
