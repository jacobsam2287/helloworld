from random import randint
a=randint(1,10)
q = int(input("Im thinking of a number from 1-10"))

if q == a:
    print("You GOT IT")
elif q < a:
    print("a little higher")
else:
    print("a little lower")
while q != a:
    q = int(input("Guess again"))

    if q == a:
        print("You GOT IT")
    elif q < a:
        print("a little higher")
    else:
        print("a little lower")
