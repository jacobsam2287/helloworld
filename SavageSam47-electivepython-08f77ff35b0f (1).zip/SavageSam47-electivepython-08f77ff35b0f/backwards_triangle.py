for a in range(100,1,-1):
    print("")
    for d in range(a):
        print(" ", end="")
    for c in range(100 - a):
        print("*", end="")