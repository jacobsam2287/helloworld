print("hello world")
a = "1"
print(a)
if a == "1":
    print("hi")